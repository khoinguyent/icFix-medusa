#!/bin/bash

# icFix Medusa Deployment Script

set -e

echo "🚀 Starting icFix Medusa deployment..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Creating from template..."
    cp env.production.template .env
    echo "📝 Please edit .env file with your production values before continuing."
    echo "🔐 Make sure to change the default passwords and secrets!"
    exit 1
fi

# Load environment variables
source .env

echo "📊 Environment loaded successfully"

# Check if Docker and Docker Compose are available
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "🐳 Docker and Docker Compose are available"

# Stop any existing containers
echo "🛑 Stopping existing containers..."
docker-compose down --remove-orphans || true

# Remove old images to ensure fresh build
echo "🧹 Cleaning up old images..."
docker-compose down --rmi all --volumes --remove-orphans || true

# Build and start services
echo "🔨 Building and starting services..."
docker-compose up -d --build

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 30

# Check service health
echo "🏥 Checking service health..."
docker-compose ps

# Check if backend is responding
echo "🔍 Testing backend connectivity..."
if curl -f http://localhost:9000/health > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend health check failed"
    docker-compose logs backend --tail=20
    exit 1
fi

# Check if storefront is responding
echo "🔍 Testing storefront connectivity..."
if curl -f http://localhost:3000 > /dev/null 2>&1; then
    echo "✅ Storefront is healthy"
else
    echo "❌ Storefront health check failed"
    docker-compose logs storefront --tail=20
    exit 1
fi

echo "🎉 Deployment completed successfully!"
echo ""
echo "📊 Service URLs:"
echo "   Backend API: http://localhost:9000"
echo "   Storefront: http://localhost:3000"
echo "   Admin Panel: http://localhost:9000/app"
echo ""
echo "📋 Useful commands:"
echo "   View logs: docker-compose logs -f"
echo "   Stop services: docker-compose down"
echo "   Restart services: docker-compose restart"
echo ""
echo "🔐 Admin credentials:"
echo "   Email: admin@icfix.com"
echo "   Password: admin123"
echo ""
echo "⚠️  Remember to change default passwords in production!"
