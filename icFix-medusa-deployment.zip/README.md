# icFix Medusa Deployment Guide

This guide will help you deploy your icFix Medusa e-commerce platform to production.

## 🚀 Quick Start

1. **Extract the deployment package**
2. **Configure environment variables**
3. **Run the deployment script**

## 📋 Prerequisites

- Docker and Docker Compose installed
- Server with at least 2GB RAM and 10GB disk space
- Domain name (optional but recommended)
- SSL certificate (recommended for production)

## 🔧 Configuration

### 1. Environment Variables

Copy the environment template and configure it:

```bash
cp env.production.template .env
```

Edit `.env` with your production values:

```bash
# Database Configuration
POSTGRES_PASSWORD=your-secure-postgres-password

# Security (CHANGE THESE!)
JWT_SECRET=your-super-secret-jwt-key
COOKIE_SECRET=your-super-secret-cookie-key

# CORS Configuration
STORE_CORS=https://yourdomain.com,https://www.yourdomain.com
ADMIN_CORS=https://yourdomain.com,https://www.yourdomain.com
AUTH_CORS=https://yourdomain.com,https://www.yourdomain.com

# Storefront Configuration
NEXT_PUBLIC_MEDUSA_BACKEND_URL=https://yourdomain.com:9000
```

### 2. Security Considerations

- **Change default passwords** for PostgreSQL and admin user
- **Use strong secrets** for JWT and cookies
- **Configure CORS** to only allow your domains
- **Enable SSL/TLS** for production use

## 🚀 Deployment

### Automated Deployment

```bash
# Make the script executable
chmod +x deploy.sh

# Run the deployment
./deploy.sh
```

### Manual Deployment

```bash
# Build and start services
docker-compose up -d --build

# Check service status
docker-compose ps

# View logs
docker-compose logs -f
```

## 📊 Service Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Storefront    │    │     Backend     │    │   PostgreSQL    │
│   (Port 3000)   │◄──►│   (Port 9000)   │◄──►│   (Port 5432)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │      Redis      │
                       │   (Port 6379)   │
                       └─────────────────┘
```

## 🔍 Health Checks

### Backend Health
```bash
curl http://localhost:9000/health
```

### Storefront Health
```bash
curl http://localhost:3000
```

### Database Connection
```bash
docker-compose exec postgres pg_isready -U medusa
```

## 📝 Post-Deployment

### 1. Create Admin User

If you need to create a new admin user:

```bash
docker-compose exec backend npx medusa user -e admin@yourdomain.com -p securepassword
```

### 2. Access Admin Panel

- **URL**: http://yourdomain.com:9000/app
- **Default credentials**: admin@icfix.com / admin123

### 3. Configure Domain

Update your DNS to point to your server's IP address.

## 🛠️ Maintenance

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f storefront
```

### Update Services
```bash
# Pull latest images and rebuild
docker-compose pull
docker-compose up -d --build
```

### Backup Database
```bash
docker-compose exec postgres pg_dump -U medusa medusa > backup.sql
```

### Restore Database
```bash
docker-compose exec -T postgres psql -U medusa medusa < backup.sql
```

## 🔒 Security Checklist

- [ ] Changed default PostgreSQL password
- [ ] Changed default admin user password
- [ ] Updated JWT and cookie secrets
- [ ] Configured CORS for your domains only
- [ ] Enabled SSL/TLS (recommended)
- [ ] Configured firewall rules
- [ ] Set up regular backups
- [ ] Updated system packages

## 🚨 Troubleshooting

### Common Issues

1. **Port conflicts**: Check if ports 3000, 9000, 5432, 6379 are available
2. **Database connection**: Verify PostgreSQL container is running
3. **Memory issues**: Ensure server has sufficient RAM
4. **Permission errors**: Check Docker and file permissions

### Getting Help

- Check service logs: `docker-compose logs [service-name]`
- Verify container status: `docker-compose ps`
- Check resource usage: `docker stats`

## 📚 Additional Resources

- [Medusa Documentation](https://docs.medusajs.com/)
- [Docker Documentation](https://docs.docker.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

## 📞 Support

For deployment issues, check the logs and refer to the troubleshooting section above.
