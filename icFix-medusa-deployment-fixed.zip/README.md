# icFix Medusa Deployment Guide

This guide will help you deploy your icFix Medusa e-commerce platform to production.

## 🚀 Quick Start

1. **Extract the deployment package**
2. **Configure environment variables**
3. **Run the deployment script**

## 📋 Prerequisites

- Docker and Docker Compose installed
- **Server with at least 4GB RAM** (2GB minimum, but 4GB+ recommended)
- 10GB+ disk space
- Domain name (optional but recommended)
- SSL certificate (recommended for production)

## ⚠️ Memory Requirements

### **Critical: Memory Allocation**
The build process requires significant memory:
- **Backend build**: Up to 4GB RAM
- **Storefront build**: Up to 4GB RAM
- **Total build memory**: Up to 8GB RAM

### **Memory Optimization Features**
- ✅ **Multi-stage builds** to reduce final image size
- ✅ **Node.js memory limits** set to 4GB per build
- ✅ **Sequential building** to manage memory usage
- ✅ **Memory checks** in deployment script

## 🔧 Configuration

### 1. Environment Variables

Copy the environment template and configure it:

```bash
cp env.production.template .env
```

Edit `.env` with your production values:

```bash
# Database Configuration
POSTGRES_PASSWORD=your-secure-postgres-password

# Security (CHANGE THESE!)
JWT_SECRET=your-super-secret-jwt-key
COOKIE_SECRET=your-super-secret-cookie-key

# CORS Configuration
STORE_CORS=https://yourdomain.com,https://www.yourdomain.com
ADMIN_CORS=https://yourdomain.com,https://www.yourdomain.com
AUTH_CORS=https://yourdomain.com,https://www.yourdomain.com

# Storefront Configuration
NEXT_PUBLIC_MEDUSA_BACKEND_URL=https://yourdomain.com:9000
```

### 2. Security Considerations

- **Change default passwords** for PostgreSQL and admin user
- **Use strong secrets** for JWT and cookies
- **Configure CORS** to only allow your domains
- **Enable SSL/TLS** for production use

## 🚀 Deployment

### Automated Deployment

```bash
# Make the script executable
chmod +x deploy.sh

# Run the deployment
./deploy.sh
```

### Manual Deployment

```bash
# Build services individually (recommended for low memory)
docker-compose build backend
docker-compose build storefront

# Start all services
docker-compose up -d

# Check service status
docker-compose ps

# View logs
docker-compose logs -f
```

## 🧠 Memory Management

### **If You Have Limited Memory (< 4GB)**

1. **Increase swap space**:
   ```bash
   # Check current swap
   free -h
   
   # Create swap file (adjust size as needed)
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

2. **Build services one by one**:
   ```bash
   # Build backend first
   docker-compose build backend
   
   # Wait for completion, then build storefront
   docker-compose build storefront
   ```

3. **Monitor memory usage**:
   ```bash
   # Watch memory during build
   watch -n 1 'free -h'
   
   # Monitor Docker memory
   docker stats
   ```

### **Memory Optimization in Dockerfiles**

The Dockerfiles include:
- `ENV NODE_OPTIONS="--max-old-space-size=4096"` for 4GB heap
- Multi-stage builds to reduce final image size
- Production-only dependencies in final stage

## 📊 Service Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Storefront    │    │     Backend     │    │   PostgreSQL    │
│   (Port 3000)   │◄──►│   (Port 9000)   │◄──►│   (Port 5432)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │      Redis      │
                       │   (Port 6379)   │
                       └─────────────────┘
```

## 🔍 Health Checks

### Backend Health
```bash
curl http://localhost:9000/health
```

### Storefront Health
```bash
curl http://localhost:3000
```

### Database Connection
```bash
docker-compose exec postgres pg_isready -U medusa
```

## 🚨 Troubleshooting

### **Heap Out of Memory Error**

If you encounter:
```
FATAL ERROR: Reached heap limit Allocation failed - JavaScript heap out of memory
```

**Solutions:**

1. **Increase system memory** (recommended)
2. **Add swap space**:
   ```bash
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

3. **Build with more memory**:
   ```bash
   # Set Docker memory limit
   docker-compose build --memory=4g backend
   docker-compose build --memory=4g storefront
   ```

4. **Use sequential building**:
   ```bash
   # Build one at a time
   docker-compose build backend
   docker-compose build storefront
   ```

### **Common Issues**

1. **Port conflicts**: Check if ports 3000, 9000, 5432, 6379 are available
2. **Database connection**: Verify PostgreSQL container is running
3. **Memory issues**: Ensure server has sufficient RAM (4GB+ recommended)
4. **Permission errors**: Check Docker and file permissions

### **Getting Help**

- Check service logs: `docker-compose logs [service-name]`
- Verify container status: `docker-compose ps`
- Check resource usage: `docker stats`
- Monitor memory: `free -h`

## 📝 Post-Deployment

### 1. Create Admin User

If you need to create a new admin user:

```bash
docker-compose exec backend npx medusa user -e admin@yourdomain.com -p securepassword
```

### 2. Access Admin Panel

- **URL**: http://yourdomain.com:9000/app
- **Default credentials**: admin@icfix.com / admin123

### 3. Configure Domain

Update your DNS to point to your server's IP address.

## 🛠️ Maintenance

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f storefront
```

### Update Services
```bash
# Pull latest images and rebuild
docker-compose pull
docker-compose up -d --build
```

### Backup Database
```bash
docker-compose exec postgres pg_dump -U medusa medusa > backup.sql
```

### Restore Database
```bash
docker-compose exec -T postgres psql -U medusa medusa < backup.sql
```

## 🔒 Security Checklist

- [ ] Changed default PostgreSQL password
- [ ] Changed default admin user password
- [ ] Updated JWT and cookie secrets
- [ ] Configured CORS for your domains only
- [ ] Enabled SSL/TLS (recommended)
- [ ] Configured firewall rules
- [ ] Set up regular backups
- [ ] Updated system packages

## 📚 Additional Resources

- [Medusa Documentation](https://docs.medusajs.com/)
- [Docker Documentation](https://docs.docker.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Node.js Memory Management](https://nodejs.org/en/docs/guides/memory-management/)

## 📞 Support

For deployment issues:
1. Check the troubleshooting section above
2. Verify system memory requirements
3. Check service logs for specific errors
4. Ensure Docker has sufficient resources allocated
